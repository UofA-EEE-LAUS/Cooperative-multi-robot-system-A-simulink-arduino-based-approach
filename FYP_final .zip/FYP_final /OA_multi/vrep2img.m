function output = vrep2img(inp_x,inp_y)
    %tranform from coppeliasim to image co-ordinate

    x = (inp_x + 12.5)*20;
    y = (inp_y + 12.5)*20;
    
    x = round(x);
    y = round(y);
    
    output = [x,y];






end