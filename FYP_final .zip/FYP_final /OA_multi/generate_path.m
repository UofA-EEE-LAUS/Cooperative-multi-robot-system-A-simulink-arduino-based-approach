function [l,p_vrep] = generate_path(prm,rob_pos, g)
 %use peter corke tool box to generate path    

    start = vrep2img(rob_pos(1),rob_pos(2));
    goal = vrep2img(g(1),g(2));
    prm.path(start, goal)
    
    p_img = prm.path(start, goal);
    l = length(p_img);
    
    p_vrep = zeros(l,2);
    
    for i = 1:1:l
            [p_vrep(i,1), p_vrep(i,2)] = img2vrep(p_img(i,1) , p_img(i,2));
    end



end