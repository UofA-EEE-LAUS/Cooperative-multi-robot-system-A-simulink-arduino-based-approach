function empty_file(file_name)
    fileId = fopen(file_name,'w');
    fclose(fileId);



end