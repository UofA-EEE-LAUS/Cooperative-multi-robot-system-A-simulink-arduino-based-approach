function store_robot_pos(sim,clientID,robothandle, file_name)
    
    [ret,rob_pos] = sim.simxGetObjectPosition(clientID, robothandle,-1,sim.simx_opmode_blocking);
    
    %file write
    fileId = fopen(file_name,'a');
    
    fprintf(fileId,append(num2str(rob_pos(1)),' ',num2str(rob_pos(2)),' ',num2str(rob_pos(3)),'\n'));

    %disp("robot pos");
    %disp(rob_pos);
    
    



end