
%controller for real time position and change of angle
%controller for real position of handle

function move_robot2pos(sim,clientID,robothandle, des_x, des_y)
        %get robot pos and orienation
        %[ret, robothandle] = sim.simxGetObjectHandle(clientID,'rover1',sim.simx_opmode_blocking);
        [ret,rob_pos] = sim.simxGetObjectPosition(clientID, robothandle,-1,sim.simx_opmode_blocking);
        [ret,rob_ornt] = sim.simxGetObjectOrientation(clientID, robothandle,-1,sim.simx_opmode_blocking);
        
        
        % get wheel handle 
        [ret, wheel_handle1]= sim.simxGetObjectHandle(clientID,'motor11',sim.simx_opmode_blocking);
        [ret, wheel_handle2]= sim.simxGetObjectHandle(clientID,'motor12',sim.simx_opmode_blocking);
        [ret, wheel_handle3]= sim.simxGetObjectHandle(clientID,'motor13',sim.simx_opmode_blocking);
        
        % current robot state
        cur_x       = rob_pos(1);
        cur_y       = rob_pos(2);
        cur_angle   = rob_ornt(3)+ 5/6 * pi; % to make the robot orientation towards the path
        
        % gps location 
        %des_x       = 2;
        %des_y       = 1;
        des_angle   = cur_angle;
        
        % inital time % robot state assumptions
        time_pre = 0;
        pre_x = 0;
        pre_y = 0;
        pre_angle =0;
        
        
        % difference in robot state
        %error testing and real time coordinates 
         e_x = des_x - cur_x;
         e_y = des_y - cur_y;
         e_angle = des_angle - cur_angle;
        
         % time 
        time_cur = sim.simxGetLastCmdTime(clientID);
        time_elapsed = time_cur - time_pre;
        time_pre     = time_cur;
        
        % current lin & ang velocity 
        v_x = (pre_x - cur_x) /time_elapsed;
        v_y = (pre_y - cur_y) /time_elapsed;
        w   = (pre_angle - cur_angle) /time_elapsed;
        
        % pd controller
        Kp = 2;   %adjust to reach goal faster
        Kd = 1;   %adjust to reach goal faster
        v_x = Kp * e_x     + Kd * v_x;
        v_y = Kp * e_y     + Kd * v_y;
        w   = Kp * e_angle + Kd * w;
    
        
        % robot current & previous  x,y,theta 
        cur_x       = rob_pos(1);
        cur_y       = rob_pos(2);
        pre_x     = cur_x;
        pre_y     = cur_y;
        pre_angle = cur_angle;
        
        % function to calculate each wheel vel from robot vx,vy,ang_z
        [v0, v1 , v2] = vel_2_wheel_vel(cur_angle, v_x, v_y, w);
        
        
        %set wheel joint velocity
        sim.simxSetJointTargetVelocity(clientID,wheel_handle1,-20*v0,sim.simx_opmode_blocking);
        sim.simxSetJointTargetVelocity(clientID,wheel_handle2,-20*v1,sim.simx_opmode_blocking);
        sim.simxSetJointTargetVelocity(clientID,wheel_handle3,-20*v2,sim.simx_opmode_blocking);


end

function [w1 , w2 , w3] = vel_2_wheel_vel(cur_angle, vel_x, vel_y , ang_z )

     rover_radius = 0.13;

     w1 = -sin(cur_angle)        * vel_x + cos(cur_angle)        * vel_y + rover_radius * ang_z;
     w2 = -sin(pi/3 - cur_angle) * vel_x - cos(pi/3 - cur_angle) * vel_y + rover_radius * ang_z;
     w3 =  sin(pi/3 + cur_angle) * vel_x - cos(pi/3 + cur_angle) * vel_y + rover_radius * ang_z;
    

end