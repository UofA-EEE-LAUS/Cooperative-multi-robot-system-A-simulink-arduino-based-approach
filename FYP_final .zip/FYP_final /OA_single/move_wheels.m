
%This is the simple controller for the wheel handles and motors. It is
%required to set velocity .
function move()
   sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
   sim.simxFinish(-1); % just in case, close all opened connections
   clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
   
   if (clientID>-1)
        disp('Connected to remote API server');
        
        % get wheel handle 
        [ret, wheel_handle1]= sim.simxGetObjectHandle(clientID,'motor11',sim.simx_opmode_blocking);
        [ret, wheel_handle2]= sim.simxGetObjectHandle(clientID,'motor12',sim.simx_opmode_blocking);
        [ret, wheel_handle3]= sim.simxGetObjectHandle(clientID,'motor13',sim.simx_opmode_blocking);
        
        %set wheel velocity 
        sim.simxSetJointTargetVelocity(clientID,wheel_handle1,2.0,sim.simx_opmode_blocking);
        sim.simxSetJointTargetVelocity(clientID,wheel_handle2,2.0,sim.simx_opmode_blocking);
        sim.simxSetJointTargetVelocity(clientID,wheel_handle3,-2.0,sim.simx_opmode_blocking);
        
        
        disp(ret)
        
   end
   %sim.simxFinish(clientID);