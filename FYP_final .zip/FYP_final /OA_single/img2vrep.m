function [x,y] = img2vrep(inp_x,inp_y)
    %tranform from image to coppeliasim co-ordinate.it sends the coordinate
    %data to the VREP for confirmation of presence coordinate and transformation .

    x = (inp_x * 0.05) - 12.5;
    y = (inp_y * 0.05) - 12.5;
    
    





end