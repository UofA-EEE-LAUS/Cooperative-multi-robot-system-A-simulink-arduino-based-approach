function move_robot_2_pos()
   sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
   sim.simxFinish(-1); % just in case, close all opened connections
   clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
   
   %arrays
   robothandle = [-1 -1 -1];
   rob_pos = zeros(3,3);
   rob_ornt= zeros(3,3);
   wheel_handle1 = [-1,-1,-1];
   wheel_handle2 = wheel_handle1;
   wheel_handle3 = wheel_handle1;
   cur_x = [-1,-1,-1];
   cur_y = cur_x;
   cur_angle = cur_x;
   des_angle = cur_x;
   des_x = cur_x;
   des_y = cur_x;
   e_x = cur_x;
   e_y = cur_x;
   e_angle = cur_x;
   
   pre_x = [0,0,0];
   pre_y = pre_x;
   pre_angle = pre_x;
   v_x = pre_x;
   v_y = pre_x;
   w = pre_x;
   v0 = pre_x;
   v1 = pre_x;
   v2 = pre_x;
   rob_reach = pre_x;
   
   %time array
   time_pre = [0,0,0];
   time_cur = time_pre;
   time_elapsed = time_pre;
   
   if (clientID>-1)
        disp('Connected to remote API server');
        
        for i= 1:3
            [ret, robothandle(i)] = sim.simxGetObjectHandle(clientID,append('rover',num2str(i)),sim.simx_opmode_blocking);
            
            % get wheel handle 
            [ret, wheel_handle1(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'1'),sim.simx_opmode_blocking);
            [ret, wheel_handle2(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'2'),sim.simx_opmode_blocking);
            [ret, wheel_handle3(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'3'),sim.simx_opmode_blocking);
            
            %get robot pos & orientation
            [ret,rob_pos(i,1:3)] = sim.simxGetObjectPosition(clientID, robothandle(i),-1,sim.simx_opmode_blocking);
            [ret,rob_ornt(i,1:3)] = sim.simxGetObjectOrientation(clientID, robothandle(i),-1,sim.simx_opmode_blocking);

            % current robot state
            cur_x(i)       = rob_pos(i,1);
            cur_y(i)       = rob_pos(i,2);
            cur_angle(i)   = rob_ornt(i,3)+ 5/6 * pi;
        
            %enter goals
            disp(append('For Robot',num2str(i),':'))
            g = input("\nEnter goal x & y position (with [] & space) =")
            des_x(i)  = g(1);
            des_y(i)  = g(2);
            des_angle(i)   = cur_angle(i);
        end
        
        
        while 1
           for i= 1:3
             % current robot state
             [ret,rob_pos(i,1:3)] = sim.simxGetObjectPosition(clientID, robothandle(i),-1,sim.simx_opmode_blocking);
             [ret,rob_ornt(i,1:3)] = sim.simxGetObjectOrientation(clientID, robothandle(i),-1,sim.simx_opmode_blocking);

             % difference in robot state
             e_x(i) = des_x(i) - cur_x(i);
             e_y(i) = des_y(i) - cur_y(i);
             e_angle(i) = des_angle(i) - cur_angle(i);


             % time 
             time_cur(i) = sim.simxGetLastCmdTime(clientID);
             time_elapsed(i) = time_cur(i) - time_pre(i);
             time_pre(i)     = time_cur(i);
 
             % current lin & ang velocity 
             v_x(i) = (pre_x(i) - cur_x(i)) /time_elapsed(i);
             v_y(i) = (pre_y(i) - cur_y(i)) /time_elapsed(i);
             w(i)   = (pre_angle(i) - cur_angle(i)) /time_elapsed(i);

             % pd controller
             Kp = 3;   %adjust to reach goal faster
             Kd = 1;   %adjust to reach goal faster
             v_x(i) = Kp * e_x(i)     + Kd * v_x(i);
             v_y(i) = Kp * e_y(i)     + Kd * v_y(i);
             w(i)   = Kp * e_angle(i) + Kd * w(i);

             % robot current & previous  x,y,theta 
             cur_x(i)     = rob_pos(i,1);
             cur_y(i)     = rob_pos(i,2);
             pre_x(i)     = cur_x(i);
             pre_y(i)     = cur_y(i);
             pre_angle(i) = cur_angle(i);

             % function to calculate each wheel vel from robot vx,vy,ang_z
            [v0(i), v1(i) , v2(i)] = vel_2_wheel_vel(cur_angle(i), v_x(i), v_y(i), w(i));


            % check if robots reached goals
            if (rob_reach(i) == 1)
                v0(i) = 0;
                v1(i) = 0;
                v1(i) = 0;
            end


            %set wheel joint velocity
            sim.simxSetJointTargetVelocity(clientID,wheel_handle1(i),-v0(i),sim.simx_opmode_blocking);
            sim.simxSetJointTargetVelocity(clientID,wheel_handle2(i),-v1(i),sim.simx_opmode_blocking);
            sim.simxSetJointTargetVelocity(clientID,wheel_handle3(i),-v2(i),sim.simx_opmode_blocking);
            
            disp(' ')
            disp('Robots current positions')
            disp(append('robot1 x=',num2str(rob_pos(1,1)),' y=',num2str(rob_pos(1,2))))
            disp(append('robot2 x=',num2str(rob_pos(2,1)),' y=',num2str(rob_pos(2,2))))
            disp(append('robot3 x=',num2str(rob_pos(3,1)),' y=',num2str(rob_pos(3,2))))
            
            %stop robot near to goal
            x_tolerance = 0.005;
            %y_tolerance = 0.005;
            if (rob_pos(i,1) < des_x(i) + x_tolerance && rob_pos(i,1) > des_x(i) -x_tolerance && rob_reach(i) ~= 1)
                rob_reach(i) = 1;
                disp(append('robot',num2str(i),' ','reached goal'))
            end
            
           end
          
           if (rob_reach(1) ==1 && rob_reach(2) == 1)
               disp('Robots Reached Goal!!')
               for i = 1:3
                sim.simxSetJointTargetVelocity(clientID,wheel_handle1(i),0,sim.simx_opmode_blocking);
                sim.simxSetJointTargetVelocity(clientID,wheel_handle2(i),0,sim.simx_opmode_blocking);
                sim.simxSetJointTargetVelocity(clientID,wheel_handle3(i),0,sim.simx_opmode_blocking);
               end 
               break;
           end
           
        end
    else
       disp('unable to connect to Coppeliasim')
   end





end

function [w1 , w2 , w3] = vel_2_wheel_vel(cur_angle, vel_x, vel_y , ang_z )

     rover_radius = 0.13;

     w1 = -sin(cur_angle)        * vel_x + cos(cur_angle)        * vel_y + rover_radius * ang_z;
     w2 = -sin(pi/3 - cur_angle) * vel_x - cos(pi/3 - cur_angle) * vel_y + rover_radius * ang_z;
     w3 =  sin(pi/3 + cur_angle) * vel_x - cos(pi/3 + cur_angle) * vel_y + rover_radius * ang_z;
    

end