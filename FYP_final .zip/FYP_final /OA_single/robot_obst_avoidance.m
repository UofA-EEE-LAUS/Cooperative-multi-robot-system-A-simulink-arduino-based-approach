function robot_obst_avoidance()
   startup_rvc; % running Peter for checking 
   sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
   sim.simxFinish(-1); % just in case, close all opened connections
   clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
   
   %read image
   inp_img = imread("colour_pic.PNG"); % this can be used to change scene.changes need to be done in the image of scene.
   bin_img =  binary_image(inp_img); % binary image file called here
   
   map = double(bin_img);
   prm = PRM(map); %path planning inbuilt
   prm.plan();
   
   if (clientID>-1) %Connection establishment
        disp('Connected to remote API server');
        [ret, robothandle] = sim.simxGetObjectHandle(clientID,'rover1',sim.simx_opmode_blocking);
        
        [ret,rob_pos] = sim.simxGetObjectPosition(clientID, robothandle,-1,sim.simx_opmode_blocking);
        
        start = vrep2img(rob_pos(1),rob_pos(2));
        g = input("\nEnter goal x & y position (with [] & space) ="); %Input of robot coordinates
        goal = vrep2img(g(1),g(2));%input of coordinate values
        prm.path(start, goal)%starting point of robot and coordinates of g . Starting and ending point similar style to navigation
        %also prm.path shows all the possible paths that can be used and
        %then it decides automatically which one to follow.
        
        p_img = prm.path(start, goal);
        l = length(p_img); % properties from image
        p_vrep = zeros(l,2);
        
        for i = 1:1:l
            [p_vrep(i,1), p_vrep(i,2)] = img2vrep(p_img(i,1) , p_img(i,2));%in comparison to the path
        end
        disp("start moving")
        for i = 1:2:l
            %arr_pos = [p_vrep(i,1), p_vrep(i,2), 0];
            %sim.simxSetObjectPosition(clientID,robothandle,-1,arr_pos,sim.simx_opmode_blocking);
            move_robot2pos(sim,clientID,robothandle,p_vrep(i,1), p_vrep(i,2)) %called another file
            %pause(0.01)
        end
        robot_stop(sim,clientID,robothandle);
        disp("goal reached")
   else
       disp("unable to connect to coppeliasim")
   end
   
   
end

function robot_stop(sim,clientID,robothandle)

[ret, wheel_handle1]= sim.simxGetObjectHandle(clientID,'motor11',sim.simx_opmode_blocking);
[ret, wheel_handle2]= sim.simxGetObjectHandle(clientID,'motor12',sim.simx_opmode_blocking);
[ret, wheel_handle3]= sim.simxGetObjectHandle(clientID,'motor13',sim.simx_opmode_blocking);
        

sim.simxSetJointTargetVelocity(clientID,wheel_handle1,0,sim.simx_opmode_blocking);
sim.simxSetJointTargetVelocity(clientID,wheel_handle2,0,sim.simx_opmode_blocking);
sim.simxSetJointTargetVelocity(clientID,wheel_handle3,0,sim.simx_opmode_blocking);
end