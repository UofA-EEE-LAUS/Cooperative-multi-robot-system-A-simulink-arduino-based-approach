function robots_3_obst_avoidance()
   startup_rvc;
   sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
   sim.simxFinish(-1); % just in case, close all opened connections
   clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
   
   %robot handle arrays
   robothandle = [-1 -1 -1];
   wheel_handle1 = [-1,-1,-1];
   wheel_handle2 = wheel_handle1;
   wheel_handle3 = wheel_handle1;
   
   %read image
   inp_img = imread("colour_pic.PNG");
   bin_img =  binary_image(inp_img);
   
   %increment by
    incby_1 = 1;
    incby_2 = 1;
    incby_3 = 1;
   
   %genrated map & plan
   map = double(bin_img);
   prm = PRM(map);
   prm.plan();
   
   %create empty files to store robot pos
   empty_file('robot_1_pos.txt');
   empty_file('robot_2_pos.txt');
   empty_file('robot_3_pos.txt');
   
   if (clientID>-1)
        disp('Connected to remote API server');
        for i =1:3
            [ret, robothandle(i)] = sim.simxGetObjectHandle(clientID,append('rover',num2str(i)),sim.simx_opmode_blocking);

            [ret,rob_pos] = sim.simxGetObjectPosition(clientID, robothandle(i),-1,sim.simx_opmode_blocking);
            
            %wheel handle 
            [ret, wheel_handle1(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'1'),sim.simx_opmode_blocking);
            [ret, wheel_handle2(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'2'),sim.simx_opmode_blocking);
            [ret, wheel_handle3(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'3'),sim.simx_opmode_blocking);
            
            
            
            disp(append('Robot no ',num2str(i)))
            g = input("\nEnter goal x & y position (with [] & space) =");
            
            %genrated path from start to goal
            [l, path] = generate_path( prm, rob_pos, g);
            
            %assign path & length for robots
            if i==1 
                l1 = l;
                p1 = path;
                incby_1 = calc_increby(l);
            end
            
            if i==2 
                l2 = l;
                p2 = path;
                incby_2 = calc_increby(l);
            end
            
            if i==3 
                l3 = l;
                p3 = path;
                incby_3 = calc_increby(l);
            end
        
        end
        
        disp("start moving")
        
        %increasing path
        inc1 = 1;
        inc2 = 1;
        inc3 = 1;
        
        
        
        %stopped robot indicator
        stop1 = 0;
        stop2 = 0;
        stop3 = 0;
        
        while 1
            
            if inc1 <= l1
                move_1robot2pos(sim,clientID,robothandle(1),wheel_handle1(1),wheel_handle2(1),wheel_handle3(1), p1(inc1,1), p1(inc1,2))
                store_robot_pos(sim,clientID,robothandle(1), 'robot_1_pos.txt');
                inc1 = inc1+ incby_1;
            else 
                robot_stop(sim,clientID,1)
                
                stop1 = 1;
            end
            
            if inc2 <= l2
                move_2robot2pos(sim,clientID,robothandle(2),wheel_handle1(2),wheel_handle2(2),wheel_handle3(2), p2(inc2,1), p2(inc2,2))
                store_robot_pos(sim,clientID,robothandle(2), 'robot_2_pos.txt');
                inc2 = inc2+ incby_2;
            else 
                robot_stop(sim,clientID,2)
                stop2 = 1;
            end
            
            if inc3 <= l3
                move_3robot2pos(sim,clientID,robothandle(3),wheel_handle1(3),wheel_handle2(3),wheel_handle3(3), p3(inc3,1), p3(inc3,2))
                store_robot_pos(sim,clientID,robothandle(3), 'robot_3_pos.txt');
                inc3 = inc3+ incby_3;
                
            else 
                robot_stop(sim,clientID,3)
                stop3 = 1;
            end
            
            if(stop1 == 1 && stop2 == 1 && stop3 == 1 )
              disp("Robots Reached Goals")
              break;
            end
        end
        
        
   else
       disp("unable to connect to coppeliasim")
   end
   
   
end

function inc = calc_increby( length)
    if length> 100 && length< 200
        inc = 4;
    elseif length> 200 && length< 300
        inc = 3;
        
    elseif length> 300
        inc = 2;
    else
        inc = 2;
    end

end

function robot_stop(sim,clientID,i)

[ret, wheel_handle1]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'1'),sim.simx_opmode_blocking);
[ret, wheel_handle2]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'2'),sim.simx_opmode_blocking);
[ret, wheel_handle3]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'3'),sim.simx_opmode_blocking);
        

sim.simxSetJointTargetVelocity(clientID,wheel_handle1,0,sim.simx_opmode_blocking);
sim.simxSetJointTargetVelocity(clientID,wheel_handle2,0,sim.simx_opmode_blocking);
sim.simxSetJointTargetVelocity(clientID,wheel_handle3,0,sim.simx_opmode_blocking);
end