clear,clc;
close all;
cnt_r1 = 1;
cnt_r2 = 1;
cnt_r3 = 1;

base = 0.6;
path_r1_x = [0*base,0*base,100*base,100*base,0*base]; 
path_r1_y = [0*base,100*base,100*base,0*base,0*base]; 
path_r2_x = [100*base,100*base,200*base,200*base,100*base]; 
path_r2_y = [100*base,200*base,200*base,100*base,100*base]; 
path_r3_x = [200*base,200*base,300*base,300*base,200*base]; 
path_r3_y = [200*base,300*base,300*base,200*base,200*base]; 

number_of_rover = 3;
rover_baee = [];

for i = 1:number_of_rover
    r = rover_class;
    r.connect2rover();
    r.askID();
    rover(r.id)=[rover_baee r];
end

for i = 1:number_of_rover
    rover(i).setInitialCoor(0,0,0);
    rover(i).sendTarget(0,0,0);
end
pause(4);
%%
% rover3 - with imu （ID2）
rover(3).sendTarget(path_r3_x(cnt_r3),path_r3_y(cnt_r3),0); % cnt_r3=2
cnt_r3 = cnt_r3+1;
%%
% rover2 (ID3)
rover(2).sendTarget(path_r2_x(cnt_r2),path_r2_y(cnt_r2),0); % cnt_r2=2
cnt_r2 = cnt_r2+1;
%%
% rover1 (ID1)
rover(1).sendTarget(path_r1_x(cnt_r1),path_r1_y(cnt_r1),0);
cnt_r1 = cnt_r1+1;

% path1
rover(1).sendTarget(path_r1_x(cnt_r1),path_r1_y(cnt_r1),0); % cnt_r1=2
cnt_r1 = cnt_r1+1;
pause(2);
rover(1).sendTarget(path_r1_x(cnt_r1),path_r1_y(cnt_r1),0); % cnt_r1=3

pause(0.5);

cnt_r1 = cnt_r1+1;

% path2
rover(2).sendTarget(path_r2_x(cnt_r2),path_r2_y(cnt_r2),0); % cnt_r2=2
cnt_r2 = cnt_r2+1;
pause(2);
rover(2).sendTarget(path_r2_x(cnt_r2),path_r2_y(cnt_r2),0); % cnt_r2=3
pause(0.5);

cnt_r2 = cnt_r2+1;

% path3
rover(3).sendTarget(path_r3_x(cnt_r3),path_r3_y(cnt_r3),0); % cnt_r3=2
cnt_r3 = cnt_r3+1;
pause(2);
rover(3).sendTarget(path_r3_x(cnt_r3),path_r3_y(cnt_r3),0); % cnt_r3=3
cnt_r3 = cnt_r3+1;
pause(2);
rover(3).sendTarget(path_r3_x(cnt_r3),path_r3_y(cnt_r3),0); % cnt_r3=4
cnt_r3 = cnt_r3+1;
pause(2);
rover(3).sendTarget(path_r3_x(cnt_r3),path_r3_y(cnt_r3),0); % cnt_r3=4

pause(0.2);

% path4
rover(2).sendTarget(path_r2_x(cnt_r2),path_r2_y(cnt_r2),0); % cnt_r2=4
cnt_r2 = cnt_r2+1;
pause(2);
rover(2).sendTarget(path_r2_x(cnt_r2),path_r2_y(cnt_r2),0); % cnt_r2=4

pause(0.5);

% path4
rover(1).sendTarget(path_r1_x(cnt_r1),path_r1_y(cnt_r1),0); % cnt_r1=4
cnt_r1 = cnt_r1+1;
pause(2);
rover(1).sendTarget(path_r1_x(cnt_r1),path_r1_y(cnt_r1),0); % cnt_r1=4