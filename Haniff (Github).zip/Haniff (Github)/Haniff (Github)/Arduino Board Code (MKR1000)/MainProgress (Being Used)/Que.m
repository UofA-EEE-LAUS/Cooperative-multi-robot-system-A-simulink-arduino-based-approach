%% Connecting matlab and Arduino IDE(TCP/IP Server)
t = tcpserver("0.0.0.0",1234);
t.ByteOrder = "big-endian";
%% Seperate task for arduino
% using variable a, when a is equal :
% 0 = set target, j
% 1 = ask coordinate, k
% 2 = set new starting point, m 
% 3 = set new coordinate, n
% 4 = identify, not declare in code

% using variables j, k, m, n for each number

