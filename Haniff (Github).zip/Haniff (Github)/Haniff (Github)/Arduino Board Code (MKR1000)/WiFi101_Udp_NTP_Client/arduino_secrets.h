//define SECRET_SSID "AndroidAP" //for no password android phone
//#define SECRET_SSID "Fauzanderani" //for iphone connection ssid
//#define SECRET_PASS "Haniff3774"   //for iphone connection password
#define SECRET_SSID "41_marmion.2.4g" //house wifi ssid
#define SECRET_PASS "41Marmionpower"  //house wifi password
