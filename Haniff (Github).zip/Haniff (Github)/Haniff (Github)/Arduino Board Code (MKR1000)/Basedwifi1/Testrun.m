
classdef Testrun
   properties
      Value {mustBeNumeric}
   end
     
   methods
       %% using properties, methods, events blocks
      function R = roundOff(object)
         R = round([object.Value],2);
      end
        
      function R = DivideBy(object,n)
         R = [object.Value] / n;
      end
      
      %% using obj method/ constructor
      function obj = Testrun(val)
          if nargin ==1
              obj.Value = val;
          end
      end
   end
end