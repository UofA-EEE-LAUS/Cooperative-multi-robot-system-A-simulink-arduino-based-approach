//#define SECRET_SSID "AndroidAP"
//#define SECRET_PASS "123456Haniff"

//#define SECRET_SSID "Fauzanderani"
//#define SECRET_PASS "Haniff3774"

//#define SECRET_SSID "41_marmion.2.4g"
//#define SECRET_PASS "41Marmionpower"

// template for ssid & pass
#define SECRET_SSID "EEELAB" 
#define SECRET_PASS "@adelaide"
