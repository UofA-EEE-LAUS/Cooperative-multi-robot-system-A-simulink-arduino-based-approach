function requestDataCommand(src,~)
if src.Connected
    % Display the server object to see that Arduino client has connected to it.
    disp("The Connected and ClientAddress properties of the tcpserver object show that the Arduino is connected.")
    disp(src)
    
    % Request the Arduino to send data.
    disp("Send the command: 1")
    write(src,1,"uint8");
end
end