function readArduinoData(src,~)
% Read the sine wave data sent to the tcpserver object.
src.UserData = read(src,src.BytesAvailableFcnCount/4,'single');

% Plot the data.
plot(src.UserData)
    
% Clear any other remaining data sent by the Arduino.
flush(src);
end