function move_to_position_3(sim,clientID,robothandle,sensorhandle,wheel_handle1,wheel_handle2,wheel_handle3, des_x, des_y)
    move_to_position_4(sim,clientID,robothandle,sensorhandle,wheel_handle1,wheel_handle2,wheel_handle3, des_x, des_y);
end