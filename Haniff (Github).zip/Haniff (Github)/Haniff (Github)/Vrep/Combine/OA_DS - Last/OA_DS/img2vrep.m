function [x,y] = img2vrep(inp_x,inp_y)
    %tranform from image to coppeliasim co-ordinate

    x = (inp_x * 0.05) - 12.5;
    y = (inp_y * 0.05) - 12.5;
    
    





end