function move_to_position_1(sim,clientID,robothandle,sensorhandle,wheel_handle1,wheel_handle2,wheel_handle3, des_x, des_y)
[ret,detectionState,arraydetectedPoint,numberdetectedObjectHandle,arraydetectedSurfaceNormalVector] = sim.simxReadProximitySensor(clientID,sensorhandle,sim.simx_opmode_blocking);
while(detectionState == true)
    [ret,detectionState,arraydetectedPoint,numberdetectedObjectHandle,arraydetectedSurfaceNormalVector] = sim.simxReadProximitySensor(clientID,sensorhandle,sim.simx_opmode_blocking);
    [ret,rob_pos] = sim.simxGetObjectPosition(clientID, robothandle,-1,sim.simx_opmode_blocking);
    move_to_position_2(sim,clientID,robothandle,sensorhandle,wheel_handle1,wheel_handle2,wheel_handle3, des_x, des_y);
    if((abs(des_x - rob_pos(1)) < 0.02 && abs(des_y - rob_pos(2)) < 0.02) ||(abs(des_x - rob_pos(1)) > 0.06 && abs(des_y - rob_pos(2)) > 0.06) )
        break;
    end
end
move_to_position_2(sim,clientID,robothandle,sensorhandle,wheel_handle1,wheel_handle2,wheel_handle3, des_x, des_y);
end
