function move_to_position(sim,clientID)

if (clientID>-1)
    disp('Connected to remote API server');
    des_x       = [2.5 1 -2.5];
    des_y       = [-1.52 3.5 -1.475];

    for i = 1:3
        [ret, robothandle(i)] = sim.simxGetObjectHandle(clientID,append('rover',num2str(i)),sim.simx_opmode_blocking);

        %wheel handle
        [ret, wheel_handle1(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'1'),sim.simx_opmode_blocking);
        [ret, wheel_handle2(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'2'),sim.simx_opmode_blocking);
        [ret, wheel_handle3(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'3'),sim.simx_opmode_blocking);

        %sensor handle
        [ret, sensor_handle(i)]= sim.simxGetObjectHandle(clientID,append('laser_sensor',num2str(i),'1'),sim.simx_opmode_blocking);

    end
    while 1
        move_to_position_0(sim,clientID,robothandle(1),sensor_handle(1),wheel_handle1(1),wheel_handle2(1),wheel_handle3(1), des_x(1),des_y(1));
        move_to_position_0(sim,clientID,robothandle(2),sensor_handle(2),wheel_handle1(2),wheel_handle2(2),wheel_handle3(2), des_x(2),des_y(2));
        move_to_position_0(sim,clientID,robothandle(3),sensor_handle(3),wheel_handle1(3),wheel_handle2(3),wheel_handle3(3), des_x(3),des_y(3));
    end
else
    disp('unable to connect to Coppeliasim')
end
