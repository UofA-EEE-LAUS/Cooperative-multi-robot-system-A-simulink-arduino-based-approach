sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1);      % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5); %clientID


if (clientID>-1)
    disp('Connected to remote API server'); %start vrep simulation
    
    % Retrieve data in a blocking fashion(called service call)
    [ret,objs]=sim.simxGetObjects(clientID,sim.sim_handle_all,sim.simx_opmode_blocking);
    objs;
    if (ret == sim.simx_return_ok)
        fprintf('Number of objects in the scene: %d\n',length(objs));
    else 
        fprintf('Remote API function call returned with error code: %d\n',res);
    end
    
    % Send some data to V-REP in a non-blocking fashion
    sim.simxAddStatusbarMessage(clientID,'Matlab & VREP connection',sim.simx_opmode_oneshot);
    
    %initial_positions for each rover
    %[ret,positions]=sim.simxGetObjectPosition(clientID,rover,-1,sim.simx_opmode_blocking);
    %positions
    
    
    %targeted/desired coordinates for rover 1, 2 & 3
    des_x       = [2.5 -0.025 -2.5];    %[x1 x2 x3]
    des_y       = [-1.52 3.475 -1.475]; %[y1 y2 y3]
    
    %input coordinates in 1 pack
    %inputCoordinates= [des_x() des_y()];
    inputCoordinates= [des_x(1) des_y(1) des_x(2) des_y(2) des_x(3) des_y(3)]
    
    %convert into floats data pack
    packedData   = sim.simxPackFloats(inputCoordinates);
    %write the String to the handle
    [returnCode] = sim.simxWriteStringStream(clientID,'stringname',packedData,sim.simx_opmode_oneshot); 
    
    %this is to get all the object handle for 'rover'
    for i = 1:3 %change if use less/more than 3 rover
        [ret, robothandle(i)] = sim.simxGetObjectHandle(clientID,append('rover',num2str(i)),sim.simx_opmode_blocking);

        %wheel handle
        [ret, wheel_handle1(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'1'),sim.simx_opmode_blocking);
        [ret, wheel_handle2(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'2'),sim.simx_opmode_blocking);
        [ret, wheel_handle3(i)]= sim.simxGetObjectHandle(clientID,append('motor',num2str(i),'3'),sim.simx_opmode_blocking);

        %sensor handle
        [ret, sensor_handle(i)]= sim.simxGetObjectHandle(clientID,append('laser_sensor',num2str(i),'1'),sim.simx_opmode_blocking);
        
    end
    while 1
        
    %every movement contributes to move_to_position matlab code
    move_to_position(sim,clientID,robothandle(1),sensor_handle(1),wheel_handle1(1),wheel_handle2(1),wheel_handle3(1), des_x(1),des_y(1));
    %disp('rover 1 moving');
    
    move_to_position(sim,clientID,robothandle(2),sensor_handle(2),wheel_handle1(2),wheel_handle2(2),wheel_handle3(2), des_x(2),des_y(2));
    %disp('rover 2 moving');
    
    move_to_position(sim,clientID,robothandle(3),sensor_handle(3),wheel_handle1(3),wheel_handle2(3),wheel_handle3(3), des_x(3),des_y(3));
    %disp('rover 3 moving');
    
    end
else
    disp('unable to connect to Coppeliasim')
end
%display in Vrep
sim.simxAddStatusbarMessage(clientID,'Goal reached',sim.simx_opmode_oneshot);
%
sim.simxFinish(-1);
%
sim.delete();
