Using the same scene as path planning and obstacle avoidance had being done using toolbox.
Communication part
-Getting data from environment
-Actual position of rover when starting the scene with move_position_code
-Rover communicating with each other
-