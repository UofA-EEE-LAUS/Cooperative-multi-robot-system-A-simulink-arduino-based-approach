%��ʾ����
vrep = remApi('remoteApi');
vrep.simxFinish(-1);
clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
disp('Connected')
%vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);%start Vrep simulation

%this is to get the object handle for 'rover'
[returnCode,rover]=vrep.simxGetObjectHandle(clientID,'rover',vrep.simx_opmode_blocking);
[returnCode,inital_positions]=vrep.simxGetObjectPosition(clientID,rover,-1,vrep.simx_opmode_blocking);
inital_positions


while clientID>-1
    pause(5/10);
    %          global postions;
    [returnCode,positions]=vrep.simxGetObjectPosition(clientID,rover,-1,vrep.simx_opmode_blocking);
    %          simxGetObjectGroupData(clientID,rover,4)
    
    positions
    %         time=time-1;
end

vrep.simxFinish(-1);

%%
vrep.delete();